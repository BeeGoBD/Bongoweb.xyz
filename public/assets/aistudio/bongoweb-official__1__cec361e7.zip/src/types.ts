export type WizardStep = 1 | 2 | 3 | 4 | 5;

export type WebsiteCategory = 'all' | 'ecommerce' | 'restaurant' | 'landing' | 'grocery' | 'blogging' | 'corporate' | 'fashion' | 'portfolio';

export type SubscriptionPlanId = 'starter' | 'pro' | 'enterprise';

export interface WebsiteDemo {
  id: string;
  fourDigitCode: string; // Special character 4-digit code e.g. '#4821'
  title: string;
  englishTitle?: string;
  banglaTitle?: string;
  category: WebsiteCategory;
  categoryLabel: string;
  description: string;
  priceTag: string;
  demoUrl: string;
  badge?: string;
  accentColor: string;
  rating: number;
  ordersCount: string;
  previewImage: string;
  heroHeadline: string;
  features: string[];
  mockData: {
    heroSub: string;
    items: {
      name: string;
      price: string;
      tag?: string;
      image: string;
    }[];
  };
}

export interface PhotoMockup {
  id: string;
  fourDigitCode: string;
  title: string;
  description?: string;
  category: string;
  categoryKey: WebsiteCategory;
  domain: string;
  imageUrl: string;
  ratio: string;
  features: string[];
  colorTheme: string;
}

export interface Testimonial {
  id: string;
  name: string;
  role: string;
  business: string;
  location: string;
  avatar: string;
  stars: number;
  highlight: string;
  quote: string;
  verified: boolean;
  date: string;
}

export interface PaymentMethod {
  id: string;
  name: string;
  bengaliName: string;
  tagline: string;
  type: string;
  color: string;
  gradient: string;
  accountType: string;
  accountNumber: string;
  feeInfo: string;
  iconType: 'bkash' | 'nagad' | 'rocket' | 'upay' | 'card' | 'bank';
}

export interface UserAccount {
  name: string;
  phone: string;
  email: string;
  password?: string;
  registeredAt: string;
  isRestricted?: boolean;
  clientId?: string;
  photoUrl?: string;
  username?: string;
  whatsapp?: string;
  numberVerified?: boolean;
  numberVerificationCallPending?: boolean;
}

export interface ClientOrder {
  id?: string;
  orderId: string; // e.g. '#BW-84920'
  demoCode: string;
  demoTitle: string;
  clientName: string;
  phone: string;
  email: string;
  companyName: string;
  domainOption: 'have_domain' | 'no_domain' | 'dont_know';
  customDomain?: string;
  paymentMethod: 'bkash' | 'nagad' | 'rocket' | 'upay';
  transactionId: string;
  makingCharge: number; // 1990
  monthlyCost: number; // 120
  status: 'pending' | 'processing' | 'completed' | 'verified' | 'cancelled' | 'bin';
  createdAt: string;
  screenshotName?: string;
  advanceAmount?: number;
  dueAmount?: number;
  paymentPhone?: string;
  businessName?: string;
  chosenDomain?: string;
  category?: string;
  hasDeliveredCredentials?: boolean;
  deliveredAdminId?: string;
  deliveredAdminPass?: string;
  binnedAt?: string;
  originalStatus?: 'pending' | 'processing' | 'completed';
}

export interface WebsiteDeliveryCredentials {
  id: string;
  orderId?: string;
  userPhone: string;
  userEmail?: string;
  websiteTitle: string;
  websiteCode: string;
  websiteAdminId: string;
  websiteAdminPass: string;
  notes?: string;
  deliveredAt: string;
  updatedAt?: number;
}

export interface PasswordResetRequest {
  id: string;
  phone: string;
  requestedAt: string;
  status: 'pending' | 'reset' | 'rejected' | 'call_not_received' | 'approved';
  resolvedAt?: string;
  approvedAt?: string;
  newPasswordAssigned?: string;
  // Detail Changes & Tagging Tracking
  userName?: string;
  oldEmail?: string;
  newEmail?: string;
  oldPhone?: string;
  newPhone?: string;
  changeType?: 'email' | 'phone' | 'both' | 'password';
  changeSummary?: string;
  tag?: string;
  reason?: string;
  type?: 'reset' | 'call_back';
}

export interface CallBackRequest {
  id: string;
  name: string;
  phone: string;
  reason: string;
  requestedAt: string;
  createdAt?: string;
  preferredTime?: string;
  status: 'pending' | 'approved' | 'rejected';
  approvedAt?: string;
  rejectedAt?: string;
  notes?: string;
}

export interface AdminConfig {
  adminId: string;
  adminEntryPassword: string;
  adminActionPassword: string;
  masterKey: string;
}

export interface SupportChatMessage {
  id: string;
  sender: 'client' | 'admin';
  text: string;
  timestamp: string;
}

export interface SupportChatThread {
  userPhone: string;
  userName: string;
  userEmail?: string;
  language?: 'bn' | 'en';
  lastMessage: string;
  lastUpdated: string;
  unreadAdminCount: number;
  unreadClientCount: number;
  expiresAt?: number; // timestamp in ms when 5-min inactivity expires
  isClosed?: boolean;
  isArchived?: boolean;
  archivedAt?: string;
  additionalMinutesAdded?: number;
  messages: SupportChatMessage[];
}

export interface UserReport {
  id: string;
  clientIdentifier: string;
  clientName: string;
  clientPhone: string;
  clientEmail?: string;
  category?: 'technical' | 'order' | 'billing' | 'domain' | 'general' | string;
  subject?: string;
  message: string;
  createdAt: string;
  status: 'pending' | 'in_progress' | 'resolved'; // strictly in pending/in_progress (পেন্ডিং/চলমান) until explicitly marked resolved
  adminReply?: string;
  adminRepliedAt?: string;
  resolvedAt?: string;
}

export interface BrandLogoConfig {
  logoType: 'image' | 'text'; // 'image' = On, 'text' = Off
  // Image mode settings:
  imageUrl?: string; // base64, SVG, or URL. Empty string means official SVG insignia
  imageName?: string;
  imageSizePx?: number; // icon size in px (e.g., 28, 36, 44, 52, 60)
  showBrandTextWithImage?: boolean; // whether to show text next to image
  // Text mode settings:
  typedLogoText: string; // typed logo text e.g. "BongoWeb", "MyBrand"
  typedSubtitle?: string; // e.g. ".xyz", "Solutions"
  textGradientTheme: 'royal' | 'violet' | 'sunset' | 'emerald' | 'monochrome';
  textFontSizePx?: number;
  textLetterSpacing?: string;
  updatedAt?: string;
}

export interface EmailRecoveryRequest {
  id: string;
  gmailIssue: 'forgot' | 'disabled' | 'no_access' | 'others';
  gmailIssueLabel: string;
  customReason?: string;
  purchasedBefore: boolean; // Yes or No
  rememberPhone: boolean; // Yes or No
  phoneNumber: string; // The phone number they entered
  createdAt: string;
  status: 'pending' | 'completed';
  decisionNote?: string;
  decisionAt?: string;
}




